MODDIR=${0%/*}
aaa=`find $MODDIR -name bootanimation.zip 2>/dev/null`
bbb=/system/product/media/bootanimation.zip
mount --bind $aaa $bbb

